# wes-cc-data-query
Command Center Data Query Service repo
