package com.fortna.kpiengine.cc.aggregator.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AggWaveStatusDetail {

	private String sorterID;
	private String waveID;
	private Integer totalQty;
	private Integer allocatedQty;
	private Integer sortedChuteQty;
	private Integer sortedContainerQty;

	@Override
	public String toString() {
		return "AggWaveStatusDetail [sorterID=" + sorterID + ", waveID=" + waveID + ", totalQty=" + totalQty
				+ ", allocatedQty=" + allocatedQty + ", sortedChuteQty=" + sortedChuteQty + ", sortedContainerQty="
				+ sortedContainerQty + "]";
	}
}
