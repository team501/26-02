package com.fortna.kpiengine.cc.dao.impl;

import org.springframework.stereotype.Repository;

import com.fortna.kpiengine.cc.dao.InductsRepository;

@Repository
public class InductsRepositoryImpl implements InductsRepository {

//	//These are the dummy keys. We need to change the keys as per requirement
//	public static final String REDIS_LIST_KEY = "InductList";
//	public static final String REDIS_SET_KEY  = "InductSET";
//	public static final String REDIS_HASH_KEY = "InductHash";
//	public static final String REDIS_ZSET_KEY = "InductZSet";
//	private static final String INDUCTS_HASH_KEY = "Inducts";
//
//	@Autowired
//	private RedisTemplate<String, Object> redisTemplate;
//
//	@Autowired
//	@Qualifier("listOperations")
//	private ListOperations<String, Induct> listOps;
//	
//	@Autowired
//	@Qualifier("setOperations")
//	 private SetOperations<String, Induct> setOps;	
//	
//	@Autowired
//	@Qualifier("hashOperations")
//	HashOperations<String, Long, Induct> hashOps;
//	
//	@Autowired
//	@Qualifier("zSetOperations")
//	ZSetOperations<String, Induct> zSetOps;
//	
//	
//	//following are the useful operations based on set, hash, list and string. Also we can use StringRedisTemplate.
//	//// ********** String *************
//
//	@Override
//	public void setInductAsString(String idKey, String induct) {
//		redisTemplate.opsForValue().set(idKey, induct);
////		redisTemplate.expire(idKey, 10, TimeUnit.SECONDS);//expire can be set on each key value pair inserted
//	}
//
//	@Override
//	public String getInductAsString(String idKey) {
//		return (String) redisTemplate.opsForValue().get(idKey);
//	}
//
//	//// ********** List *************
//	@Override
//	public void AddToInductList(Induct Induct) {
//		 listOps.leftPush(REDIS_LIST_KEY, Induct);
//	}
//
//	@Override
//	public List<Induct> getInductsList(long start, long stop) {
//		return listOps.range(REDIS_LIST_KEY, start, stop);
//	}
//
//	@Override
//	public Long getInductsListCount() {
//		return listOps.size(REDIS_LIST_KEY);
//	}
//	
//	//********** Set *************
//
//	@Override
//	public void AddToInductsSet(Induct Inducts) {
//		setOps.add(REDIS_SET_KEY, Inducts);
//		
//	}
//
//	@Override
//	public Set<Induct> getInductsSetMembers() {
//		return setOps.members(REDIS_SET_KEY);
//	}
//
//	@Override
//	public boolean isSetMember(Induct Induct) {
//		return setOps.isMember(REDIS_SET_KEY,Induct);
//	}
//
//	 //********** Hash *************
//	
//	@Override
//	public void saveHash(Induct induct) {
//		hashOps.put(REDIS_HASH_KEY, induct.getInductCreated(), induct);
//	}
////
////	@Override
////	public void updateHash(Induct Induct) {
////		hashOps.put(REDIS_HASH_KEY, Induct.getId(), Induct);
////	}
//
////	@Override
////	public Map<Integer, Induct> findAllHash() {
////		return hashOps.entries(REDIS_HASH_KEY);
////	}
//
//	@Override
//	public Induct findInHash(long id) {
//		return hashOps.get(REDIS_HASH_KEY, id);
//	}
//
//	@Override
//	public List<Induct> findMany(List<Long> ids) {
//		return hashOps.multiGet(REDIS_HASH_KEY, ids);
//	}
//	
//	@Override
//	public void deleteHash(long id) {
//		hashOps.delete(REDIS_HASH_KEY, id);
//	}
//	
//	@Override
//	public Map<Long, Induct> findAllInducts() {
//		return hashOps.entries(INDUCTS_HASH_KEY);
//	}
//	
//	//********** Ordered Set *************
//	@Override
//	public Set<Induct> getListOfInducts(double start, double stop) {
//		return zSetOps.rangeByScore(REDIS_ZSET_KEY,start,stop);
//	}
//
//	@Override
//	public void addZSetMember(Induct induct) {
//		zSetOps.add(REDIS_ZSET_KEY,induct,induct.getInductCreated());
//	}
//	@Override
//	public Long getCountOfInducts(double start, double stop) {
//		return (long) zSetOps.rangeByScore(REDIS_ZSET_KEY, start,stop).size();
//	}
}
