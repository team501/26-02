package com.fortna.kpiengine.cc.service;

import java.util.List;

import com.fortna.kpiengine.cc.exception.BusinessServiceException;
import com.fortna.kpiengine.cc.model.UnitSorterData;
import com.fortna.kpiengine.cc.model.UnitSorterDetails;

public interface UnitSorterDetailsDataService {

	List<UnitSorterData> getUSSDetails(Long startTime, List<Long> keys) throws BusinessServiceException;

}
