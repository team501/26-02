package com.fortna.kpiengine.cc.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class USSDataset {

	private String sorterid;
	
	private Integer sorts;
	
	private Integer sortsPercent;
	
	private Integer inducts;
	
	private Integer inductsPercent;
	
	List<InductsForLastXhours> inductsLastXHours;
	
	List<InductsForLastXDays> inductsLastXDays;
}
