package com.fortna.kpiengine.cc.aggregator.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AggInductStationStatusDetail {

	private String sorterID;
	private Date loginTS;
	private Date logoutTS;
	private Integer duration;
	private String loginUserID;
	private String logoutUserID;

	@Override
	public String toString() {
		return "AggInductStationStatusDetail [sorterID=" + sorterID + ", loginTS=" + loginTS + ", logoutTS=" + logoutTS
				+ ", duration=" + duration + ", loginUserID=" + loginUserID + ", logoutUserID=" + logoutUserID + "]";
	}

}
