package com.fortna.kpiengine.cc.repository;

import java.util.Optional;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.fortna.kpiengine.cc.aggregator.model.AggWaveStatus;

@Repository
public interface USSWaveStatusRepository extends PagingAndSortingRepository<AggWaveStatus, Long> {
	
	public Optional<AggWaveStatus> findById(Long key);

}
