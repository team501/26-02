package com.fortna.kpiengine.cc.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SortsForLastXhours {
	private Integer hour;
	
	private Integer sorts;
}
