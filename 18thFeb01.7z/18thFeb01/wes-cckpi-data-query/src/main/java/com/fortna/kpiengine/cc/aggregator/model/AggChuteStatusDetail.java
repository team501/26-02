package com.fortna.kpiengine.cc.aggregator.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AggChuteStatusDetail {

	private String sorterID;
	private Date statusTs;
	private String status;
	private String assigned;

	@Override
	public String toString() {
		return "AggChuteStatusDetail [sorterID=" + sorterID + ", statusTs=" + statusTs + ", status=" + status
				+ ", assigned=" + assigned + "]";
	}

}
