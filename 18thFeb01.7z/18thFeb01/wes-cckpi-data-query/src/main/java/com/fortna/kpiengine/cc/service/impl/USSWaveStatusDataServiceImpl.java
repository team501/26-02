package com.fortna.kpiengine.cc.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fortna.kpiengine.cc.aggregator.model.AggWaveStatus;
import com.fortna.kpiengine.cc.constants.Constants;
import com.fortna.kpiengine.cc.exception.BusinessServiceException;
import com.fortna.kpiengine.cc.model.WaveStatus;
import com.fortna.kpiengine.cc.repository.USSWaveStatusRepository;
import com.fortna.kpiengine.cc.service.USSWaveStatusDataService;

@Service
public class USSWaveStatusDataServiceImpl implements USSWaveStatusDataService{

	private static final Logger LOGGER = LoggerFactory.getLogger(USSWaveStatusDataServiceImpl.class);

	@Autowired
	USSWaveStatusRepository ussWaveStatusRepository;

	@Override
	public List<WaveStatus> getWaveStatusData(List<Long> keys, String sorterId) throws BusinessServiceException {
		try {
			List<AggWaveStatus> data = keys.parallelStream().map(key -> {
				Optional<AggWaveStatus> aggItem = ussWaveStatusRepository.findById(key);
				return aggItem.isPresent()?aggItem.get():null;
			}).collect(Collectors.toList());
			data.removeAll(Collections.singleton(null));
			return exctractUSSData(data,sorterId);
		}catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSWaveStatusDataServiceImpl:getWaveStatusData message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSWaveStatusDataServiceImpl:getWaveStatusData message: "+e.getMessage());
		}

	}

	private List<WaveStatus> exctractUSSData(List<AggWaveStatus> data, String sorterId) throws BusinessServiceException {
		List<WaveStatus> waveStatuses = new ArrayList<>();
		if(sorterId.trim().isEmpty()) {
			WaveStatus overallWaveStatus = getwaveStatusFromAggData(data);
			waveStatuses.add(overallWaveStatus);
		}else {

		}
		return waveStatuses;
	}

	private WaveStatus getwaveStatusFromAggData(List<AggWaveStatus> data) throws BusinessServiceException {
		try {
			int waveCount=0;
			int totalQuantity = 0;
			int allocatedQuantity = 0;
			int sortedChuteQuantity = 0;
			int units = 0;
			int remaining = 0;
			int sortedPercent = 0;
			int allocatedPercent = 0;
			int remainingPercent = 0;
			for (AggWaveStatus aggWaveStatus : data) {
				waveCount+=aggWaveStatus.getDetails().size();
				totalQuantity += aggWaveStatus.getDetails().parallelStream().mapToInt(mapper->mapper.getTotalQty()).sum(); 
				allocatedQuantity += aggWaveStatus.getDetails().parallelStream().mapToInt(mapper->mapper.getAllocatedQty()).sum(); 
				sortedChuteQuantity += aggWaveStatus.getDetails().parallelStream().mapToInt(mapper->mapper.getSortedChuteQty()).sum(); 
				remaining += totalQuantity - sortedChuteQuantity;
				units += remaining+sortedChuteQuantity+allocatedQuantity;
			}
			sortedPercent = (int) ((sortedChuteQuantity/(double)units)*100);
			allocatedPercent = (int) ((allocatedQuantity/(double)units)*100);
			remainingPercent = (int) ((remaining/(double)units)*100);
			return new WaveStatus(null, allocatedQuantity, sortedChuteQuantity, (totalQuantity-sortedChuteQuantity), waveCount, totalQuantity, allocatedPercent, sortedPercent,remainingPercent);

		}catch(ArithmeticException ae) {
			LOGGER.error(Constants.errorMessage+" USSWaveStatusDataServiceImpl:getwaveStatusFromAggData message: ",ae);
			throw new BusinessServiceException(Constants.errorMessage+" USSWaveStatusDataServiceImpl:getwaveStatusFromAggData message: "+ae.getMessage());
		}
		catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSWaveStatusDataServiceImpl:getwaveStatusFromAggData message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSWaveStatusDataServiceImpl:getwaveStatusFromAggData message: "+e.getMessage());
		}
	}
}