package com.fortna.kpiengine.cc.repository;

import java.util.Optional;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.fortna.kpiengine.cc.aggregator.model.AggItem;

@Repository
public interface USSInductsRepository extends PagingAndSortingRepository<AggItem, Long> {
	
	public Optional<AggItem> findById(Long key);

}
