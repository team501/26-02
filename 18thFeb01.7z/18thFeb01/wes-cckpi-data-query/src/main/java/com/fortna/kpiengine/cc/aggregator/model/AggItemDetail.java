package com.fortna.kpiengine.cc.aggregator.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AggItemDetail {

	private String unitSorterID;
	private String waveName;
	private String inductStationID;
	private Integer sortedCount = 0;
	private Integer inductCount = 0;
	private Integer recircCount = 0;
	private Integer minRecircCount = 0;
	private Integer maxRecircCount = 0;

	@Override
	public String toString() {
		return "AggItemDetail [unitSorterID=" + unitSorterID + ", waveName=" + waveName + ", inductStationID="
				+ inductStationID + ", sorterCount=" + sortedCount + ", inductCount=" + inductCount + ", recircCount="
				+ recircCount + ", minRecircCount=" + minRecircCount + ", maxRecircCount=" + maxRecircCount + "]";
	}

}
