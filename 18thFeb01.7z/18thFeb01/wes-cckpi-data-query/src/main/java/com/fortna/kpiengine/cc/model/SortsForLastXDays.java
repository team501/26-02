package com.fortna.kpiengine.cc.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SortsForLastXDays {
	private String date;
	
	private Integer sorts;
}
