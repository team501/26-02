package com.fortna.kpiengine.cc.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fortna.kpiengine.cc.aggregator.model.AggItem;
import com.fortna.kpiengine.cc.constants.Constants;
import com.fortna.kpiengine.cc.exception.BusinessServiceException;
import com.fortna.kpiengine.cc.model.UnitSorterData;
import com.fortna.kpiengine.cc.repository.USSInductsRepository;
import com.fortna.kpiengine.cc.repository.UnitSorterDetailsRepository;
import com.fortna.kpiengine.cc.service.UnitSorterDetailsDataService;
import com.fortna.kpiengine.cc.service.util.USSInductsDataServiceUtil;

@Service
public class UnitSorterDetailsDataServiceImpl implements UnitSorterDetailsDataService{

	private static final Logger LOGGER = LoggerFactory.getLogger(UnitSorterDetailsDataServiceImpl.class);
	
	@Autowired
	UnitSorterDetailsRepository unitSorterDetailsRepository;
	
	@Autowired
	USSInductsRepository ussInductsRepository;

	@Override
	public List<UnitSorterData> getUSSDetails(Long startTime, List<Long> keys) throws BusinessServiceException {
		List<AggItem> data = new ArrayList<>();
		try {
			data = keys.parallelStream().map(key -> {
				Optional<AggItem> aggItem = ussInductsRepository.findById(key);
				return aggItem.isPresent()?aggItem.get():null;
			}).collect(Collectors.toList());
			data.removeAll(Collections.singleton(null));
			return USSInductsDataServiceUtil.getInductsAndSortsForEachSorter(data);
		}catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" UnitSorterDetailsDataServiceImpl:getUSSDataSetForLastXMins message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" UnitSorterDetailsDataServiceImpl:getUSSDataSetForLastXMins message: "+e.getMessage());
		}
	}
}