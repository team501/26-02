package com.fortna.kpiengine.cc.constants;

import java.time.format.DateTimeFormatter;

public interface Constants {
	public static final String INVALID_DATE_FORMAT = "The timestamps should not be empty and it should be in yyyy/MM/dd, yyyy-MM-dd, yyyy-MM-dd HH:mm:ss and yyyy/MM/dd HH:mm:ss format only";

	public static final Integer secondsInMilli = 1000;
	public static final Integer minutesInMilli = secondsInMilli * 60;
	public static final Integer hoursInMilli = minutesInMilli * 60;
	public static final Integer daysInMilli = hoursInMilli * 24;
	public static final String DAYS = "days";
	public static final String SORTS = "sorts";
	public static final String Inducts = "inducts";
	public static DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("yyyyMMddHHmm");
	public static final String errorMessage = "Error while fetching data! ";
}
