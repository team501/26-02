package com.fortna.kpiengine.cc.service;

import java.util.List;

import com.fortna.kpiengine.cc.exception.BusinessServiceException;
import com.fortna.kpiengine.cc.model.WaveStatus;

public interface USSWaveStatusDataService {

	public List<WaveStatus> getWaveStatusData(List<Long> keys, String sorterId) throws BusinessServiceException;
}
