package com.fortna.kpiengine.cc.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@RedisHash("UnitSorterDetails")
public class UnitSorterDetails {
	@Id
	Long id;
	String sorterId;
	Integer inducts;
	Integer sorts;
}
