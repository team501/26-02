package com.fortna.kpiengine.cc.repository;

import java.util.Optional;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.fortna.kpiengine.cc.model.UnitSorterDetails;

@Repository
public interface UnitSorterDetailsRepository extends PagingAndSortingRepository<UnitSorterDetails, Long> {
	
	public Optional<UnitSorterDetails> findById(Long key);

}
