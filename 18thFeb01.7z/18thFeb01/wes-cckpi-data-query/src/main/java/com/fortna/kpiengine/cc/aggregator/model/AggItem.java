package com.fortna.kpiengine.cc.aggregator.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@RedisHash("AggItem")
public class AggItem {

	@Id
	private Long id;
	private List<AggItemDetail> details = new ArrayList<>();

	@Override
	public String toString() {
		return "AggItem [id=" + id + ", details=" + details + "]";
	}

}
