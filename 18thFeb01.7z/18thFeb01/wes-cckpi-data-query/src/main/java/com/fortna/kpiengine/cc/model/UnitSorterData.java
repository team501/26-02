package com.fortna.kpiengine.cc.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UnitSorterData {
	String sorterId;
	Integer inducts;
	Integer sorts;
}
