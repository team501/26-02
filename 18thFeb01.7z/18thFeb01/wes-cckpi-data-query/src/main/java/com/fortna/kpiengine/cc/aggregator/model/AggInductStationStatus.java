package com.fortna.kpiengine.cc.aggregator.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@RedisHash("AggInductStationStatus")
public class AggInductStationStatus {

	@Id
	private String stationID;
	private List<AggInductStationStatusDetail> details = new ArrayList<>();

	@Override
	public String toString() {
		return "AggInductStationStatus [stationID=" + stationID + ", details=" + details + "]";
	}

}
