package com.fortna.kpiengine.cc.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fortna.kpiengine.cc.aggregator.model.AggItem;
import com.fortna.kpiengine.cc.common.utils.DateTimeUtil;
import com.fortna.kpiengine.cc.constants.Constants;
import com.fortna.kpiengine.cc.exception.BusinessServiceException;
import com.fortna.kpiengine.cc.model.USSDataset;
import com.fortna.kpiengine.cc.model.UnitSorterData;
import com.fortna.kpiengine.cc.repository.USSInductsRepository;
import com.fortna.kpiengine.cc.service.USSInductsDataService;
import com.fortna.kpiengine.cc.service.util.USSInductsDataServiceUtil;

@Service
public class USSInductsDataServiceImpl implements USSInductsDataService{

	private static final Logger LOGGER = LoggerFactory.getLogger(USSInductsDataServiceImpl.class);

	@Autowired
	USSInductsRepository ussInductsRepository;

	@Override
	public USSDataset getUSSDataSetForLastXMins(Long startTime,List<Long> keys, String sorterId,Integer goalVal,String reqData,String duration) throws BusinessServiceException {
		List<AggItem> data = new ArrayList<>();
		try {
			data = keys.parallelStream().map(key -> {
				Optional<AggItem> aggItem = ussInductsRepository.findById(key);
				return aggItem.isPresent()?aggItem.get():null;
			}).collect(Collectors.toList());
			data.removeAll(Collections.singleton(null));
			return exctractUSSData(startTime,data,sorterId,goalVal,reqData,duration);
		}catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceImpl:getUSSDataSetForLastXMins message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceImpl:getUSSDataSetForLastXMins message: "+e.getMessage());
		}
	}

	private USSDataset exctractUSSData(Long startTime, List<AggItem> data, String sorterId, Integer goalVal, String reqData, String duration) throws BusinessServiceException {
		try {
			//numberOfMinutes for last X days would be X*24*60
			USSDataset ussDataset = getLastXDaysData(startTime,sorterId,reqData,duration);
			UnitSorterData unitSorterData = USSInductsDataServiceUtil.getSorts(data);
			Integer inducts = unitSorterData.getInducts();
			Integer sorts = unitSorterData.getSorts();

			Integer inductsPercentVal = (int) Math.round( ((inducts/(double)goalVal)*100));

			Integer sortsPercentVal = (int) Math.round( ((sorts/(double)goalVal)*100));
			ussDataset.setInducts(inducts);
			ussDataset.setSorts(sorts);
			ussDataset.setInductsPercent(inductsPercentVal);
			ussDataset.setSortsPercent(sortsPercentVal);
			return ussDataset;
		}catch(ArithmeticException e) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceImpl:exctractUSSData message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceImpl:exctractUSSData message: "+e.getMessage());
		}catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceImpl:exctractUSSData message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceImpl:exctractUSSData message: "+e.getMessage());
		}
	}

	public USSDataset getLastXDaysData(Long startTime, String sorterId, String reqData, String duration) throws BusinessServiceException {

		USSDataset ussDataset =new USSDataset();
		try {
			Integer durationInMinutes = USSInductsDataServiceUtil.getDurationInMinutes(duration);
			Long startOfStartTime =  Long.parseLong(startTime.toString().substring(0, 8).concat("0000"));
			List<Long> keys = DateTimeUtil.getKeysBasedOnRange(startOfStartTime, durationInMinutes, Constants.formatter);

			List<AggItem> specifiedDurationData = keys.parallelStream().map(key -> {
				Optional<AggItem> aggItem = ussInductsRepository.findById(key);
				return aggItem.isPresent()?aggItem.get():null;
			}).collect(Collectors.toList());

			if(duration.contains(Constants.DAYS)) {
				ussDataset.setInductsLastXDays(USSInductsDataServiceUtil.getInductsForLastXDays(specifiedDurationData,1440));
			}else {
				ussDataset.setInductsLastXHours(USSInductsDataServiceUtil.getInductsForLastXHours(specifiedDurationData,60));
			}
			return ussDataset;
		}catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceImpl:getSorts message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceImpl:getSorts message: "+e.getMessage());
		}
	}
}
