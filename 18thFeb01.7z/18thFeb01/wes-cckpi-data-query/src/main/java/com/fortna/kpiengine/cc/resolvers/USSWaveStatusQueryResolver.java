package com.fortna.kpiengine.cc.resolvers;

import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.fortna.kpiengine.cc.common.utils.DateTimeUtil;
import com.fortna.kpiengine.cc.exception.BusinessServiceException;
import com.fortna.kpiengine.cc.model.WaveStatus;
import com.fortna.kpiengine.cc.service.USSWaveStatusDataService;

@Component
public class USSWaveStatusQueryResolver implements GraphQLQueryResolver {
	
	private DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("yyyyMMddHHmm");
	
	@Autowired
    private USSWaveStatusDataService ussWaveStatusDataService;

	public List<WaveStatus> getWaveStatusData(Long startTime, Integer xMins,String sorterId) throws BusinessServiceException {
		List<Long> keys = DateTimeUtil.getKeysBasedOnRange(startTime, xMins, formatter);
		return ussWaveStatusDataService.getWaveStatusData(keys, sorterId);
	}
}