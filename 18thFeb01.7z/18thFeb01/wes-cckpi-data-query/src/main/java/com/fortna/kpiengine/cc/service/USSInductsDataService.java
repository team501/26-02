package com.fortna.kpiengine.cc.service;

import java.util.List;

import com.fortna.kpiengine.cc.exception.BusinessServiceException;
import com.fortna.kpiengine.cc.model.USSDataset;
import com.fortna.kpiengine.cc.model.UnitSorterData;


public interface USSInductsDataService {

	USSDataset getUSSDataSetForLastXMins(Long startTime,List<Long> keys, String sorterId, Integer goalVal, String reqData, String duration) throws BusinessServiceException;

}
