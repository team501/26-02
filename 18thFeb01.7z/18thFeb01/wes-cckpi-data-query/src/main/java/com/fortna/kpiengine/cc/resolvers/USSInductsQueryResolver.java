package com.fortna.kpiengine.cc.resolvers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.fortna.kpiengine.cc.common.utils.DateTimeUtil;
import com.fortna.kpiengine.cc.exception.BusinessServiceException;
import com.fortna.kpiengine.cc.model.USSDataset;
import com.fortna.kpiengine.cc.model.UnitSorterData;
import com.fortna.kpiengine.cc.service.USSInductsDataService;
import com.fortna.kpiengine.cc.service.UnitSorterDetailsDataService;

@Component
public class USSInductsQueryResolver implements GraphQLQueryResolver {
	
	private DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("yyyyMMddHHmm");
	
	private final SimpleDateFormat simpleDateFormat = 
            new SimpleDateFormat("yyyyMMddHHmm");
	@Autowired
    private USSInductsDataService inductsService;
	
	@Autowired
    private UnitSorterDetailsDataService unitSorterDetailsDataService;

	public USSDataset getUSSDataForLastXMins(Long startTime, Integer xMins, String sorterId, 
		Integer goalVal,String reqData,String duration) throws ParseException, BusinessServiceException {
		List<Long> keys = DateTimeUtil.getKeysBasedOnRange(startTime, xMins, formatter);
		return  inductsService.getUSSDataSetForLastXMins(startTime,keys, sorterId,goalVal, reqData,duration);
	}
	public List<UnitSorterData> getUnitSorterDetails(Long startTime, Integer xMins) throws BusinessServiceException{
		List<Long> keys = DateTimeUtil.getKeysBasedOnRange(startTime, xMins, formatter);
		return unitSorterDetailsDataService.getUSSDetails(startTime,keys);
	}
}