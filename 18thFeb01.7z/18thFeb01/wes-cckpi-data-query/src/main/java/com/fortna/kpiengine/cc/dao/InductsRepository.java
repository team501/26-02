package com.fortna.kpiengine.cc.dao;

public interface InductsRepository {
//	
//	// String
//		void setInductAsString(String idKey, String induct);
//
//		String getInductAsString(String idKey);
//		
//		
//		// list
//		void AddToInductList(Induct induct);
//
//		List<Induct> getInductsList(long start, long stop);
//
//		Long getInductsListCount();
//		
//		// Set
//		void AddToInductsSet(Induct programmers);
//
//		Set<Induct> getInductsSetMembers();
//		
//		boolean isSetMember(Induct programmer);
//		
//		// Hash
//		void saveHash(Induct induct);
////
////		void updateHash(Programmer programmer);
////
////		Map<Integer, Programmer> findAllHash();
//
//		Induct findInHash(long id);
//
//		public List<Induct> findMany(List<Long> ids);
//		
//		void deleteHash(long id);
//
//		public Map<Long, Induct> findAllInducts();
//
//		Long getCountOfInducts(double start, double stop);
//		
//		Set<Induct> getListOfInducts(double start, double stop);
//
//		void addZSetMember(Induct induct);

}
