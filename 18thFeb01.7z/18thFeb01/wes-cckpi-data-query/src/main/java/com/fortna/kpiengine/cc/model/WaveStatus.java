package com.fortna.kpiengine.cc.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WaveStatus{
	
    private String sorterId;
	
	private Integer allocated;

	private Integer sorted;
	
	private Integer remaining;
	
	private Integer waves;
	
	private Integer units;
	
	private Integer allocatedPercentage;
	
	private Integer sortedPercentage;
	
	private Integer remainingPercentage;
}