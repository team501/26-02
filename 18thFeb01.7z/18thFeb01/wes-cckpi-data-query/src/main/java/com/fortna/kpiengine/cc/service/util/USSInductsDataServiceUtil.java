package com.fortna.kpiengine.cc.service.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fortna.kpiengine.cc.aggregator.model.AggItem;
import com.fortna.kpiengine.cc.aggregator.model.AggItemDetail;
import com.fortna.kpiengine.cc.constants.Constants;
import com.fortna.kpiengine.cc.exception.BusinessServiceException;
import com.fortna.kpiengine.cc.model.InductsForLastXDays;
import com.fortna.kpiengine.cc.model.InductsForLastXhours;
import com.fortna.kpiengine.cc.model.UnitSorterData;

public class USSInductsDataServiceUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(USSInductsDataServiceUtil.class);

	public static List<InductsForLastXDays> getInductsForLastXDays(List<AggItem> data, int unit) throws BusinessServiceException {
		try {
			List<InductsForLastXDays> lstInductsForLastXDays = new ArrayList<>();
			int counter = 0;
			int inducts = 0;
			int sorts = 0;
			for (AggItem item : data) {
				if(item==null) {
					counter++;
					continue;
				}
				Integer inductsCount = item.getDetails().parallelStream().mapToInt(mapper->mapper.getInductCount()).sum();
				Integer sortsCount = item.getDetails().parallelStream().mapToInt(mapper->mapper.getSortedCount()).sum();
				sorts+=sortsCount;
				inducts+=inductsCount;
				if(counter==unit-1) {
					InductsForLastXDays sortsForLastXDays = new InductsForLastXDays();
					sortsForLastXDays.setDate(item.getId().toString().substring(0, 8));
					sortsForLastXDays.setSorts(sorts);
					sortsForLastXDays.setInducts(inducts);
					lstInductsForLastXDays.add(sortsForLastXDays);
					counter=0;
					inducts = 0;
					sorts = 0;
				}
				counter++;
			}
			return lstInductsForLastXDays;
		}catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceUtil:getInductsForLastXDays message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceUtil:getInductsForLastXDays message: "+e.getMessage());

		}
	}
	public static List<InductsForLastXhours>  getInductsForLastXHours(List<AggItem> data,int unit) throws BusinessServiceException {
		try {
			List<InductsForLastXhours> lstInductsForLastXHours = new ArrayList<>();
			int counter = 0;
			int inducts = 0;
			int sorts = 0;
			for (AggItem item : data) {
				if(item==null) {
					counter++;
					continue;
				}
				Integer inductsCount = item.getDetails().parallelStream().mapToInt(mapper->mapper.getInductCount()).sum();
				Integer sortsCount = item.getDetails().parallelStream().mapToInt(mapper->mapper.getSortedCount()).sum();
				sorts+=sortsCount;
				inducts+=inductsCount;
				if(counter !=0 && counter%unit == 0 ) {
					InductsForLastXhours sortsForLastXDays = new InductsForLastXhours();
					sortsForLastXDays.setHour(counter/unit);
					sortsForLastXDays.setSorts(sorts);
					sortsForLastXDays.setInducts(inducts);
					lstInductsForLastXHours.add(sortsForLastXDays);
					inducts = 0;
					sorts = 0;
				}
				counter++;
			}
			return lstInductsForLastXHours;
		}catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceUtil:getInductsForLastXHours message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceUtil:getInductsForLastXHours message: "+e.getMessage());
		}
	}
	public static Integer getDurationInMinutes(String duration) throws BusinessServiceException {
		try {
			String[] strArr = duration.trim().split("-");
			int x=0;
			int minutes=0;
			if(strArr.length>0) {
				x = Integer.parseInt(strArr[0]);
				minutes = strArr[1].equalsIgnoreCase(Constants.DAYS)?1440:60;
			}
			return x*minutes;
		}catch(IndexOutOfBoundsException ioe) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceUtil:getDurationInMinutes message: ",ioe);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceUtil:getDurationInMinutes message: "+ioe.getMessage());
		}
		catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceUtil:getDurationInMinutes message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceUtil:getDurationInMinutes message: "+e.getMessage());
		}
	}

	public static UnitSorterData getSorts(List<AggItem> data) throws BusinessServiceException {
		try {
			Integer inducts = 0;
			Integer sorts = 0;
			for(AggItem item:data) {
				Integer inductsCount = item.getDetails().parallelStream().mapToInt(mapper->mapper.getInductCount()).sum();
				Integer sortsCount = item.getDetails().parallelStream().mapToInt(mapper->mapper.getSortedCount()).sum();
				sorts+=sortsCount;
				inducts+=inductsCount;
			}
			return new UnitSorterData(null,inducts, sorts);
		}catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceUtil:getSorts  message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceUtil:getSorts message: "+e.getMessage());
		}
	}
	
	public static List<UnitSorterData> getInductsAndSortsForEachSorter(List<AggItem> data) throws BusinessServiceException {
		try {
			Map<String,Integer> mapInducts = new HashMap<>();
			Map<String,Integer> mapSorts = new HashMap<>();

			Integer inducts = 0;
			Integer sorts = 0;
			for(AggItem item:data) {

				for (AggItemDetail aggItem : item.getDetails()) {
					if(mapInducts.containsKey(aggItem.getUnitSorterID())){
						mapSorts.put(aggItem.getUnitSorterID(), mapSorts.get(aggItem.getUnitSorterID())+aggItem.getSortedCount());
						mapInducts.put(aggItem.getUnitSorterID(), mapInducts.get(aggItem.getUnitSorterID())+aggItem.getInductCount());
					}else {
						mapSorts.put(aggItem.getUnitSorterID(), aggItem.getSortedCount());
						mapInducts.put(aggItem.getUnitSorterID(), aggItem.getInductCount());
					}
						
				}
			}
			List<UnitSorterData> list = new ArrayList<>();
			for (Entry<String, Integer> entry : mapInducts.entrySet())
			{
				String sorterid = entry.getKey();
				UnitSorterData ussData = new UnitSorterData(sorterid, entry.getValue(), mapSorts.get(sorterid));
				list.add(ussData);
			}
			return list;
		}catch(Exception e) {
			LOGGER.error(Constants.errorMessage+" USSInductsDataServiceUtil:getInductsAndSortsForEachSorter message: ",e);
			throw new BusinessServiceException(Constants.errorMessage+" USSInductsDataServiceUtil:getInductsAndSortsForEachSorter message: "+e.getMessage());
		}
	}
}
