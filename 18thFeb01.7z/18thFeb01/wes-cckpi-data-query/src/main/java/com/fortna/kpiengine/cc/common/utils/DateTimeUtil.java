package com.fortna.kpiengine.cc.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.fortna.kpiengine.cc.constants.Constants;

/**
 * Provides utility methods for date
 * convertDateToString
 * convertDateToStringWithOutTime
 * convertStringToDate
 * truncateTime
 * truncateToEnd
 * getKeysBasedOnRange
 */
public class DateTimeUtil {

	/**
	 * Converts a date object into String
	 * 
	 * @param date
	 * @param format could be like yyyy-MM-dd HH:mm:ss or yyyy-MM-dd
	 * @return value type String
	 */
	public static String convertDateToString(Date date, String format) {
		String ret = "";
		SimpleDateFormat sdf = null;
		try {
			if (date != null) {
				sdf = new SimpleDateFormat(format);
				ret = sdf.format(date);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * Converts a date object into String
	 * 
	 * @param date
	 * @param format could be like yyyy-MM-dd HH:mm:ss or yyyy-MM-dd
	 * @return value type String
	 */
	public static String convertDateToStringWithOutTime(Date date, String format) {
		String ret = "";
		SimpleDateFormat sdf = null;
		try {
			if (date != null) {
				sdf = new SimpleDateFormat(format);
				ret = sdf.format(date);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * Converts String into date.
	 * 
	 * @param date
	 * @param format could be either yyyy-MM-dd HH:mm:ss or yyyy-MM-dd
	 * @return value type date
	 */
	public static Date convertStringToDate(String date, String format) {
		Date ret = null;
		SimpleDateFormat sdf = null;
		try {
			sdf = new SimpleDateFormat(format);
			ret = sdf.parse(date);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * Used to truncate date time.
	 * 
	 * @param date
	 * @return value type date
	 */
	public static Date truncateTime(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	/**
	 * Used to truncate date time.
	 * 
	 * @param date
	 * @return value type date
	 */
	public static Date truncateToEnd(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 59);
		return cal.getTime();
	}

	/**
	 * Converts String into date and truncate as start date.
	 * 
	 * @param startDate
	 * @param format    could be either yyyy-MM-dd HH:mm:ss or yyyy-MM-dd
	 * @return value type date
	 */
	public static Date getFilterStartDate(String startDate, String format) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(DateTimeUtil.convertStringToDate(startDate, format));
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}

	/**
	 * Converts String into date and truncate as end date.
	 * 
	 * @param endDate
	 * @param format  could be either yyyy-MM-dd HH:mm:ss or yyyy-MM-dd
	 * @return value type date
	 */
	public static Date getFilterEndDate(String endDate, String format) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(DateTimeUtil.convertStringToDate(endDate, format));
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 59);
		return cal.getTime();
	}

	public static int compareDates(Date firstDate, Date secondDate) {
		return firstDate.compareTo(secondDate);
	}

	public static List<Long> getKeysBasedOnRange(Long startTime, Integer xMins, DateTimeFormatter format) {

		List<Long> keys = new ArrayList<>();
		keys.add(startTime);

		LocalDateTime startDate = LocalDateTime.parse(startTime.toString(), format);
		for(int i=1;i<xMins;i++) {
			LocalDateTime localDate  = startDate.minusMinutes(i);
			keys.add(Long.parseLong(localDate.format(format)));
		}
		return keys;
	}

	public static Integer getNumberofMinutes(Long startTime, Integer dataPoints, SimpleDateFormat simpleDateFormat) throws ParseException {

		Date currentDate = truncateTime(simpleDateFormat.parse(startTime.toString()));
		Date lastDate = addDays(currentDate);
		return (int) ((currentDate.getTime() - lastDate.getTime())/(Constants.minutesInMilli));
	}

	private static Date addDays(Date currentDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(currentDate);
		cal.add(Calendar.DATE, 5); 
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
}
