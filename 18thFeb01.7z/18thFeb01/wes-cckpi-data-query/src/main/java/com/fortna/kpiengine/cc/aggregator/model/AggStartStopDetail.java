package com.fortna.kpiengine.cc.aggregator.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AggStartStopDetail {

	private Date startTs;
	private Date endTs;
	private Integer duration;
	private String eventType;
	private String errorCode;
	private String errorDesc;

	@Override
	public String toString() {
		return "AggStartStopDetail [startTs=" + startTs + ", endTs=" + endTs + ", duration=" + duration + ", eventType="
				+ eventType + ", errorCode=" + errorCode + ", errorDesc=" + errorDesc + "]";
	}
}
